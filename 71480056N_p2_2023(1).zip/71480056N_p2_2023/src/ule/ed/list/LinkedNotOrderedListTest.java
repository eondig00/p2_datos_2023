package ule.ed.list;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import org.junit.*;


public class LinkedNotOrderedListTest {
	private LinkedNotOrderedList<String> lista;
	
	@Before
	public void setUp() {
		 lista= new LinkedNotOrderedList<String>();
	}

	@Test
	public void LinkedVaciaTest() {
		assertEquals(0,lista.size());
	}
	
	// test addFirst comprueba que dispara excepción
	@Test(expected=NullPointerException.class)
	public void LinkedAddFirstElementoNuloTest() {
			lista.addFirst(null);
	}
	
	@Test
	public void LinkedAddFirstTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
	}
	
	// test addLast comprueba que dispara excepción
	@Test
	public void LinkedAddPenultTest() {
		lista.addPenult("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addPenult("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addPenult("7");
		Assert.assertEquals("(3 7 2 )", lista.toString());
	}
	
	@Test(expected=NullPointerException.class)
	public void LinkedAddPenultElementoNuloTest() {
			lista.addPenult(null);
	}
	
	// test addLast comprueba que dispara excepción
		@Test
		public void LinkedAddLastTest() {
			lista.addLast("2");
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addLast("3");
			Assert.assertEquals("(2 3 )", lista.toString());
			lista.addLast("7");
			Assert.assertEquals("(2 3 7 )", lista.toString());
		}
		
		@Test(expected=NullPointerException.class)
		public void LinkedAddLastElementoNuloTest() {
				lista.addLast(null);
		}

	//test de iteradores
	@Test
	public void LinkedIteratorTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		Iterator<String>  iter=lista.iterator();
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("3", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	}
	
	@Test
	public void LinkedEvenIteratorNElemsParTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		lista.addFirst("8");
		Assert.assertEquals("(8 7 3 2 )", lista.toString());

		Iterator<String>  iter=lista.evenPosIterator();
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	}
	
	@Test
	public void LinkedListFromUntilIterato() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		lista.addFirst("8");
		Assert.assertEquals("(8 7 3 2 )", lista.toString());

		Iterator<String>  iter=lista.fromUntilIterator(2, 4);
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("3", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	}
	
	
	// TEST ITERADORES EN LISTA VACÍA
	@Test(expected=NoSuchElementException.class)
	public void LinkedNextListaVaciaTest() {
			lista.iterator().next();	}
	
	
	//TEST reverse
	@Test
	public void LinkedtestReverse() {
	
	lista.addFirst("6");
	Assert.assertFalse(lista.isEmpty());
	Assert.assertEquals("(6 )", lista.toString());
	lista.addFirst("5");
	Assert.assertEquals("(5 6 )", lista.toString());
	lista.addFirst("4");
	Assert.assertEquals("(4 5 6 )", lista.toString());
	lista.addFirst("4");
	Assert.assertEquals("(4 4 5 6 )", lista.toString());
	Assert.assertEquals("(6 5 4 4 )", lista.reverse().toString());
	Assert.assertEquals("(4 4 5 6 )", lista.toString()); // queda en el mismo estado
	
	}
	
	//test add
	@Test
   public void LinkedAddPosTest() {
        lista.addPos("A", 1);
        assertEquals("(A )", lista.toString());

        lista.addPos("B", 2);
        assertEquals("(A B )", lista.toString());

        lista.addPos("C", 1);
        assertEquals("(C A B )", lista.toString());

        lista.addPos("D", 4);
        assertEquals("(C A B D )", lista.toString());
        
        lista.addPos("D", 98);
        assertEquals("(C A B D D )", lista.toString());

        assertThrows(IllegalArgumentException.class, () -> lista.addPos("E", 0));
        assertThrows(IllegalArgumentException.class, () -> lista.addPos("E", -1));
       
            LinkedNotOrderedList<String> list = new LinkedNotOrderedList<>();
            list.addFirst("C");
            list.addFirst("B");
            list.addFirst("A");

            // Add element in position 2
            list.addPos("X", 2);
            assertEquals("(A X B C )", list.toString());

            // Add element in first position
            list.addPos("Y", 1);
            assertEquals("(Y A X B C )", list.toString());

            // Add element in last position
            list.addPos("Z", 5);
            assertEquals("(Y A X B Z C )", list.toString());

            // Try to add element in negative position
            assertThrows(IllegalArgumentException.class, () -> list.addPos("W", -1));

            // Try to add null element
            assertThrows(NullPointerException.class, () -> list.addPos(null, 3));
    }
	
	@Test
	public void LinkedFromUntilNotIncluded() {
	    LinkedNotOrderedList<String> list = new LinkedNotOrderedList<String>();
	    list= new LinkedNotOrderedList<String>();
	    list.addFirst("A");
	    list.addFirst("B");
	    list.addFirst("C");
	    list.addFirst("D");
	    list.addFirst("E");
	    //(E D C B A )

	    String result = list.FromUntilNotIncluded(1, 3);
	    assertEquals("(D )", result);

	    result = list.FromUntilNotIncluded(3, 10);
	    assertEquals("(B A )", result);

	    result = list.FromUntilNotIncluded(10, 20);
	    assertEquals("()", result);
	}

	@Test
	public void linkedListTestRemoveLast() throws EmptyCollectionException {
	    LinkedNotOrderedList<Integer> list = new LinkedNotOrderedList<Integer>();
	    list.addFirst(3);
	    list.addFirst(2);
	    list.addFirst(1);
	    // 1 2 3
	    int removed = list.removelast();
	    assertEquals(3, removed);
	    assertEquals(2, list.size());

	    removed = list.removelast();
	    assertEquals(2, removed);
	    assertEquals(1, list.size());

	    removed = list.removelast();
	    assertEquals(1, removed);
	    assertEquals(0, list.size());

	    assertThrows(EmptyCollectionException.class, () -> list.removelast());
	}

    @Test
    public void testFromUntilNotIncluded() {
    	LinkedNotOrderedList<String> list;
        list = new LinkedNotOrderedList<>();
        list.addFirst("A");
        list.addPos("B", 2);
        list.addPos("C", 3);
        list.addPos("D", 4);
        list.addPos("E", 5);

        // Test valid range
        assertEquals("(B )", list.FromUntilNotIncluded(1, 3));
        assertEquals("(D E )", list.FromUntilNotIncluded(3, 10));

        // Test range beyond the end of the list
        assertEquals("()", list.FromUntilNotIncluded(10, 20));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFromUntilNotIncludedInvalidArgs() {
    	LinkedNotOrderedList<String> list;
        list = new LinkedNotOrderedList<>();
        list.addFirst("A");
        list.addPos("B", 2);
        list.addPos("C", 3);
        list.addPos("D", 4);
        list.addPos("E", 5);

        // Test invalid arguments
        list.FromUntilNotIncluded(3, 1);
    }
    
    //
    @Test
    public void testRemoveElemFirstElement() throws EmptyCollectionException {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        list.addFirst("B");
        list.addFirst("C");
        int position = list.removeElem("C");
        assertEquals(1, position);
        assertEquals(2, list.size());
        assertEquals("(B A )", list.toString());
    }

    @Test
    public void testRemoveElemLastElement() throws EmptyCollectionException {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        list.addFirst("B");
        list.addFirst("C");
        int position = list.removeElem("A");
        assertEquals(3, position);
        assertEquals(2, list.size());
        assertEquals("(C B )", list.toString());
    }

    @Test
    public void testRemoveElemMiddleElement() throws EmptyCollectionException {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        list.addFirst("B");
        list.addFirst("C");
        int position = list.removeElem("B");
        assertEquals(2, position);
        assertEquals(2, list.size());
        assertEquals("(C A )", list.toString());
    }

    @Test
    public void testRemoveElemDuplicateElement() throws EmptyCollectionException {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        list.addFirst("B");
        list.addFirst("C");
        list.addFirst("B");
        int position = list.removeElem("B");
        assertEquals(1, position);
        assertEquals(3, list.size());
        assertEquals("(C B A )", list.toString());
    }

    @Test
    public void testRemoveElemSingleElementList() throws EmptyCollectionException {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        int position = list.removeElem("A");
        assertEquals(0, position);
        assertEquals(0, list.size());
        assertEquals("()", list.toString());
    }

    @Test
    public void testRemoveElemNotFoundEmptyList() {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
	    list.addFirst("B");
        list.addFirst("C");
	    assertThrows(NoSuchElementException.class, () -> list.removeElem("A"));
    }

    @Test
    public void testRemoveElemNotFoundNonEmptyList() {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        list.addFirst("B");
        list.addFirst("C");
        assertThrows(NoSuchElementException.class, () -> list.removeElem("D"));
    }

    @Test
    public void testRemoveElemEmptyList() {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        assertThrows(EmptyCollectionException.class, () -> list.removeElem("A"));
    }

    @Test(expected = NullPointerException.class)
    public void testRemoveElemNull() throws EmptyCollectionException {
    	LinkedNotOrderedList<String> list;
	    list= new LinkedNotOrderedList<String>();
        list.addFirst("A");
        list.removeElem(null);
    }
    
    @Test(expected=EmptyCollectionException.class)
	public void removeFirstElementoNuloTest() throws EmptyCollectionException {
		lista.removeFirst();
	}
					
	@Test
	public void removeFirstTest() throws EmptyCollectionException {
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("7");
		lista.addLast("10");
		Assert.assertEquals("(2 3 7 10 )", lista.toString());	
		lista.removeFirst();
		assertEquals("(3 7 10 )", lista.toString());
				
	}
	
	@Test(expected=EmptyCollectionException.class)
	public void removePenultElementoNuloTest() throws EmptyCollectionException {
		lista.removePenult();
	}
	
	@Test(expected=NoSuchElementException.class)
	public void removePenultNoPenultTest() throws EmptyCollectionException {
		lista.addLast("2");
		Assert.assertEquals("(2 )", lista.toString());	
		lista.removePenult();
						
	}
	
	@Test
	public void removePenultTest() throws EmptyCollectionException {
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("7");
		lista.addLast("10");
		Assert.assertEquals("(2 3 7 10 )", lista.toString());	
		lista.removePenult();
		assertEquals("(2 3 10 )", lista.toString());
						
	}
	
	public void getElemPosElementoTest() {
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("7");
		lista.addLast("10");
		Assert.assertEquals("(2 3 7 10 )", lista.toString());	
		assertEquals(lista.getElemPos(4), "10");
	}

			
	@Test(expected= IllegalArgumentException.class)
	public void getElemPosElementoPositionNegativaTest() throws IllegalArgumentException {
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("7");
		lista.addLast("10");
		Assert.assertEquals("(2 3 7 10 )", lista.toString());	
		lista.getElemPos(-1);									
	}
	
	@Test(expected= IllegalArgumentException.class)
	public void  getElemPosElementoPositionMayorTest() throws IllegalArgumentException{
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("7");
		lista.addLast("10");
		Assert.assertEquals("(2 3 7 10 )", lista.toString());	
		lista.getElemPos(10);									
	}

	@Test
    public void testGetElemPos() {
		lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

		assertEquals("A", lista.getElemPos(1));
        assertEquals("B", lista.getElemPos(2));
        assertEquals("C", lista.getElemPos(3));
        assertEquals("D", lista.getElemPos(4));
        assertThrows(IllegalArgumentException.class, () -> lista.getElemPos(0));
        assertThrows(IllegalArgumentException.class, () -> lista.getElemPos(5));
    }

    @Test
    public void testGetPosLast() {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals(4, lista.getPosLast("D"));
        assertEquals(3, lista.getPosLast("C"));
        assertEquals(2, lista.getPosLast("B"));
        assertEquals(1, lista.getPosLast("A"));
    }

    @Test
    public void testRemoveAll() throws EmptyCollectionException {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals(1, lista.removeAll("A"));
        assertEquals("(B C D )", lista.toString());
        assertEquals(1, lista.removeAll("B"));
        assertEquals("(C D )", lista.toString());
        assertEquals(1, lista.removeAll("D"));
        assertEquals("(C )", lista.toString());
        assertThrows(NullPointerException.class, () -> lista.removeAll(null));
        assertThrows(NoSuchElementException.class, () -> lista.removeAll("E"));
        ArrayNotOrderedList<String> emptyList = new ArrayNotOrderedList<String>(10);
        assertThrows(EmptyCollectionException.class, () -> emptyList.removeAll("A"));
    }

    @Test
    public void testRemoveElemPos() throws EmptyCollectionException {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals("A", lista.removeElemPos(1));
        assertEquals("(B C D )", lista.toString());
        assertEquals("C", lista.removeElemPos(2));
        assertEquals("(B D )", lista.toString());
        assertEquals("D", lista.removeElemPos(2));
        assertEquals("(B )", lista.toString());
        assertThrows(EmptyCollectionException.class, () -> new ArrayNotOrderedList<String>(10).removeElemPos(1));
        assertThrows(IllegalArgumentException.class, () -> lista.removeElemPos(0));
        assertThrows(IllegalArgumentException.class, () -> lista.removeElemPos(5));
    }

    @Test
    public void testRemovePosLast() throws EmptyCollectionException{
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals(4, lista.removePosLast("D"));
        assertEquals("(A B C )", lista.toString());
        assertEquals(3, lista.removePosLast("C"));
        assertEquals("(A B )", lista.toString());
    }
}

		
				
