package ule.ed.list;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.*;


public class ArrayNotOrderedListTest {
	private ArrayNotOrderedList<String> lista;
	
	@Before
	public void setUp() {
		 lista= new ArrayNotOrderedList<String>();
	}

	@Test
	public void ArrayVaciaTest() {
		assertEquals(0,lista.size());
	}
	
	// test addFirst comprueba que dispara excepción
	@Test(expected=NullPointerException.class)
	public void ArrayAddFirstElementoNuloTest() {
			lista.addFirst(null);
	}
	
	@Test
	public void ArrayAddFirstTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
	}
	
	@Test
	public void ArrayAddFirstExpandCapacityTest() {
		lista=new ArrayNotOrderedList<String>(3);
		
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		lista.addFirst("10");
		Assert.assertEquals("(10 7 3 2 )", lista.toString());		
	}


	//test de iteradores
	@Test
	public void ArrayIteratorTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		Iterator<String>  iter=lista.iterator();
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("3", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	}
	
	@Test
	public void ArrayEvenIteratorNElemesParTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		lista.addFirst("8");
		Assert.assertEquals("(8 7 3 2 )", lista.toString());

		Iterator<String>  iter=lista.evenPosIterator();
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	}
	
	@Test
	public void ArrayListFromUntilIterator() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		lista.addFirst("8");
		Assert.assertEquals("(8 7 3 2 )", lista.toString());

		Iterator<String>  iter=lista.fromUntilIterator(2, 4);
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("3", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	} 
	
	@Test(expected = IllegalArgumentException.class)
	public void testArrayNotOrderedListIteratorFromToUntilNegativeFrom() {
	    Iterator<String> iter = lista.fromUntilIterator(-1, 1);
	    iter.next();
	}

	@Test
	public void testArrayNotOrderedListIteratorFromToUntilGreaterUntil() {
	    lista.addFirst("7");
	    Iterator<String> iter = lista.fromUntilIterator(1, 9);
	    iter.next();
	}

	@Test(expected = IllegalArgumentException.class)
	public void testArrayNotOrderedListIteratorFromToUntilGreaterFrom() {
	    Iterator<String> iter = lista.fromUntilIterator(3, 2);
	    iter.next();
	}

	@Test(expected = NoSuchElementException.class)
	public void testArrayNotOrderedListIteratorFromToUntilEqualFromUntil() {
	    Iterator<String> iter = lista.fromUntilIterator(1, 1);
	    iter.next();
	}

	@Test(expected = NoSuchElementException.class)
	public void testArrayNotOrderedListIteratorFromToUntilEqualFromGreaterThanCount() {
	    lista.addFirst("7");
	    Iterator<String> iter = lista.fromUntilIterator(2, 2);
	    iter.next();
	}

	public void testArrayNotOrderedListIteratorFromToUntilEqualUntilGreaterThanCount() {
	    lista.addFirst("7");
	    Iterator<String> iter = lista.fromUntilIterator(1, 3);
	    iter.next();
	}


	// TEST ITERADORES EN LISTA VACÍA
	@Test(expected=NoSuchElementException.class)
	public void ArrayNextListaVaciaTest() {
			lista.iterator().next();	}
	
	@Test(expected=NoSuchElementException.class)
	public void ArrayEvenIteratorNListaVaciaTest() {
			lista.evenPosIterator().next();	}
	
	@Test(expected=NoSuchElementException.class)
	public void ArrayListFromUntilIteratorListaVaciaTest() {
			lista.fromUntilIterator(1, 1).next();	}
	
	
	//TEST reverse
	@Test
	public void ArraytestReverse() {
	
	lista.addFirst("6");
	Assert.assertFalse(lista.isEmpty());
	Assert.assertEquals("(6 )", lista.toString());
	lista.addFirst("5");
	Assert.assertEquals("(5 6 )", lista.toString());
	lista.addFirst("4");
	Assert.assertEquals("(4 5 6 )", lista.toString());
	lista.addFirst("4");
	Assert.assertEquals("(4 4 5 6 )", lista.toString());
	Assert.assertEquals("(6 5 4 4 )", lista.reverse().toString());
	Assert.assertEquals("(4 4 5 6 )", lista.toString()); // queda en el mismo estado
	
	}

	//Tests hechos por mi:
	
	//test size
	@Test
	public void ArraySizeTest() {
		lista=new ArrayNotOrderedList<String>(3);
		Assert.assertEquals( 0 , lista.size());
		lista.addLast("2");
		Assert.assertEquals( 1 , lista.size());
		lista.addLast("6");
		Assert.assertEquals( 2 , lista.size());
		lista.addLast("3");
		Assert.assertEquals( 3 , lista.size());
	}
	
	// test addLast
		@Test(expected=NullPointerException.class)
		public void ArrayAddLastElementoNuloTest() {
				lista.addLast(null);
		}
		
		@Test
		public void ArrayAddLastTest() {
			lista.addLast("2");
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addLast("3");
			Assert.assertEquals("(2 3 )", lista.toString());
			lista.addLast("7");
			Assert.assertEquals("(2 3 7 )", lista.toString());
		}
		
		@Test
		public void ArrayAddLastExpandCapacityTest() {
			lista=new ArrayNotOrderedList<String>(3);
			
			lista.addLast("2");
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addLast("3");
			Assert.assertEquals("(2 3 )", lista.toString());
			lista.addLast("7");
			Assert.assertEquals("(2 3 7 )", lista.toString());
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());		
		}
		
		// test addPenult
		@Test(expected=NullPointerException.class)
		public void ArrayAddPenultElementoNuloTest() {
			lista.addPenult(null);
		}
				
		@Test
		public void ArrayAddPenultTest() {
			lista.addPenult("2");
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addPenult("3");
			Assert.assertEquals("(3 2 )", lista.toString());
			lista.addPenult("7");
			Assert.assertEquals("(3 7 2 )", lista.toString());
		}
		
		@Test
		public void ArrayAddPenultExpandCapacityTest() {
			lista=new ArrayNotOrderedList<String>(3);
					
			lista.addPenult("2");
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addPenult("3");
			Assert.assertEquals("(3 2 )", lista.toString());
			lista.addPenult("7");
			Assert.assertEquals("(3 7 2 )", lista.toString());
			lista.addPenult("10");
			Assert.assertEquals("(3 7 10 2 )", lista.toString());		
		}

		// test addPos
		@Test(expected=NullPointerException.class)
		public void ArrayAddPosElementoNuloTest() {
				lista.addPos(null, 1);
		}
		
		@Test(expected=IllegalArgumentException.class)
		public void ArrayAddPosPosicionNegativaTest()  throws IndexOutOfBoundsException {
				lista.addPos("2", -1);
		}
						
		@Test
		public void ArrayAddPosTest() {
			lista.addPos("2", 1);
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addPos("3", 2);
			Assert.assertEquals("(2 3 )", lista.toString());
			lista.addPos("7", 2);
			Assert.assertEquals("(2 7 3 )", lista.toString());
		}
				
		@Test
		public void ArrayAddPosExpandCapacityTest() {
			lista=new ArrayNotOrderedList<String>(3);
							
			lista.addPos("2", 1);
			Assert.assertFalse(lista.isEmpty());
			Assert.assertEquals("(2 )", lista.toString());
			lista.addPos("3", 2);
			Assert.assertEquals("(2 3 )", lista.toString());
			lista.addPos("7", 2);
			Assert.assertEquals("(2 7 3 )", lista.toString());
			lista.addPos("10", 3);
			Assert.assertEquals("(2 7 10 3 )", lista.toString());		
		}
		
		// test removeFirst
		@Test(expected=EmptyCollectionException.class)
		public void ArrayRemoveFirstElementoNuloTest() throws EmptyCollectionException {
			lista.removeFirst();
		}
						
		@Test
		public void ArrayRemoveFirstTest() throws EmptyCollectionException {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.removeFirst();
			assertEquals("(3 7 10 )", lista.toString());
					
		}
				
		// test removeLast
		@Test(expected=EmptyCollectionException.class)
		public void ArrayRemoveLastElementoNuloTest() throws EmptyCollectionException {
			lista.removelast();
		}
								
		@Test
		public void ArrayRemoveLastTest() throws EmptyCollectionException {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.removelast();
			assertEquals("(2 3 7 )", lista.toString());
							
		}
		
		// test removePenult
		@Test(expected=EmptyCollectionException.class)
		public void ArrayRemovePenultElementoNuloTest() throws EmptyCollectionException {
			lista.removePenult();
		}
		
		@Test(expected=NoSuchElementException.class)
		public void ArrayRemovePenultNoPenultTest() throws EmptyCollectionException {
			lista.addLast("2");
			Assert.assertEquals("(2 )", lista.toString());	
			lista.removePenult();
							
		}
		
		@Test
		public void ArrayRemovePenultTest() throws EmptyCollectionException {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.removePenult();
			assertEquals("(2 3 10 )", lista.toString());
							
		}
		
		// test removeElem

	
	    @Test
	    public void testRemoveElem() throws EmptyCollectionException {
	    	ArrayNotOrderedList<String> list;
	    	list = new ArrayNotOrderedList<String>();
	        list.addFirst("A");
	        list.addFirst("B");
	        list.addFirst("C");
	        list.addFirst("B");
	        //BCBA
	        int position = list.removeElem("B");
	        assertEquals(1, position);
	        assertEquals(3, list.size());
	        assertEquals("(C B A )", list.toString());
	    }
	
	    @Test
	    public void testRemoveElemNotFound() {
	    	ArrayNotOrderedList<String> list;
	    	list = new ArrayNotOrderedList<String>();
	        list.addFirst("A");
	        list.addFirst("B");
	        list.addFirst("C");
	        list.addFirst("B");
	        assertThrows(NoSuchElementException.class, () -> list.removeElem("D"));
	    }
	
	    @Test
	    public void testRemoveElemEmptyList() {
	        assertThrows(EmptyCollectionException.class, () -> lista.removeElem("A"));
	    }
		
	    @Test(expected=EmptyCollectionException.class)
		public void ArrayRemoveElemElementoNuloTest() throws EmptyCollectionException {
			lista.removeElem("");
		}
				
		@Test(expected=NoSuchElementException.class)
		public void ArrayRemoveElemElementoNoEstaTest() throws NoSuchElementException, EmptyCollectionException {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.removeElem("8");
		}
			
		
		@Test
		public void ArrayRemoveElemTest() throws EmptyCollectionException {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.removeElem("7");
			assertEquals("(2 3 10 )", lista.toString());
									
		}
		
		// test getElemPos
						
		public void ArrayGetElemPosElementoTest() {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			assertEquals(lista.getElemPos(4), "10");
		}
	
				
		@Test(expected= IllegalArgumentException.class)
		public void  ArrayGetElemPosElementoPositionNegativaTest() throws IllegalArgumentException {
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.getElemPos(-1);									
		}
		
		@Test(expected= IllegalArgumentException.class)
		public void  ArrayGetElemPosElementoPositionMayorTest() throws IllegalArgumentException{
			lista.addLast("2");
			lista.addLast("3");
			lista.addLast("7");
			lista.addLast("10");
			Assert.assertEquals("(2 3 7 10 )", lista.toString());	
			lista.getElemPos(10);									
		}

	//
	@Test
	public void testFromUntilNotIncludedValidIndices() {
		lista.addFirst("2");
		lista.addFirst("3");
		lista.addFirst("7");
		lista.addFirst("8");
		assertEquals("(7 )", lista.FromUntilNotIncluded(1, 3));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromUntilNotIncludedFromIndexLessThanOne() {
		lista.FromUntilNotIncluded(0, 3);
	}

	public void testFromUntilNotIncludedUntilIndexGreaterThanSize() {
		lista.addFirst("2");
		lista.addFirst("3");
		lista.FromUntilNotIncluded(1, 5);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromUntilNotIncludedFromIndexGreaterThanUntilIndex() {
    	lista.addFirst("2");
    	lista.FromUntilNotIncluded(3, 1);
	}
	
	@Test
    public void testGetElemPos() {
		lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

		assertEquals("A", lista.getElemPos(1));
        assertEquals("B", lista.getElemPos(2));
        assertEquals("C", lista.getElemPos(3));
        assertEquals("D", lista.getElemPos(4));
        assertThrows(IllegalArgumentException.class, () -> lista.getElemPos(0));
        assertThrows(IllegalArgumentException.class, () -> lista.getElemPos(5));
    }

    @Test
    public void testGetPosLast() {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals(4, lista.getPosLast("D"));
        assertEquals(3, lista.getPosLast("C"));
        assertEquals(2, lista.getPosLast("B"));
        assertEquals(1, lista.getPosLast("A"));
        assertThrows(NullPointerException.class, () -> lista.getPosLast(null));
        assertThrows(NoSuchElementException.class, () -> lista.getPosLast("E"));
    }

    @Test
    public void testRemoveAll() throws EmptyCollectionException {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals(1, lista.removeAll("A"));
        assertEquals("(B C D )", lista.toString());
        assertEquals(1, lista.removeAll("B"));
        assertEquals("(C D )", lista.toString());
        assertEquals(1, lista.removeAll("D"));
        assertEquals("(C )", lista.toString());
        assertThrows(NullPointerException.class, () -> lista.removeAll(null));
        assertThrows(NoSuchElementException.class, () -> lista.removeAll("E"));
        ArrayNotOrderedList<String> emptyList = new ArrayNotOrderedList<String>(10);
        assertThrows(EmptyCollectionException.class, () -> emptyList.removeAll("A"));
    }

    @Test
    public void testToString() {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals("(A B C D )", lista.toString());
        ArrayNotOrderedList<String> emptyList = new ArrayNotOrderedList<String>(10);
        assertEquals("()", emptyList.toString());
    }

    @Test
    public void testRemoveElemPos() throws EmptyCollectionException {
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals("A", lista.removeElemPos(1));
        assertEquals("(B C D )", lista.toString());
        assertEquals("C", lista.removeElemPos(2));
        assertEquals("(B D )", lista.toString());
        assertEquals("D", lista.removeElemPos(2));
        assertEquals("(B )", lista.toString());
        assertThrows(EmptyCollectionException.class, () -> new ArrayNotOrderedList<String>(10).removeElemPos(1));
        assertThrows(IllegalArgumentException.class, () -> lista.removeElemPos(0));
        assertThrows(IllegalArgumentException.class, () -> lista.removeElemPos(5));
    }

    @Test
    public void testRemovePosLast() throws EmptyCollectionException{
    	lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        lista.addLast("D");

    	assertEquals(4, lista.removePosLast("D"));
        assertEquals("(A B C )", lista.toString());
        assertEquals(3, lista.removePosLast("C"));
        assertEquals("(A B )", lista.toString());
    }

}

				
				

