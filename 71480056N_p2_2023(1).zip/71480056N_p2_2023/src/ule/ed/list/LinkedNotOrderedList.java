package ule.ed.list;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedNotOrderedList<T> implements INotOrderedList<T> {

	// referencia al primer de la lista
	private Node<T> front;

	// NO SE PUEDEN AÑADIR MÁS ATRIBUTOS A LA LISTA

	private class Node<T> {

		Node(T element) {
			this.elem = element;
			this.next = null;
		}

		T elem;

		Node<T> next;
	}
	///////
	///// ITERADOR normal //////////

	// @SuppressWarnings("hiding")
	private class LinkedListIterator<T> implements Iterator<T> {
		private Node<T> current;
		public LinkedListIterator(Node<T> aux) {
			current = aux;
		}

		@Override
		public boolean hasNext() {
			return (current != null);
		}

		@Override
		public T next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}

			T result = current.elem;
			current = current.next;
			return result;
		}
	}
	
	private class LinkedListPosIterator<T> implements Iterator<T> {
	
	        private Node<T> current;
	    
	        public LinkedListPosIterator(Node<T> aux) {
	            current = aux;
	        }
	    
	        @Override
	        public boolean hasNext() {
	            return current != null && current.next != null;
	        }
	    
	        @Override
	        public T next() {
	            if (!hasNext()) {
	                throw new NoSuchElementException();
	            }
	            current = current.next;
	            T result = current.elem;
	            current = current.next;
	            return result;
	        }

	}

	private class LinkedListFromUntilIterator<T> implements Iterator<T> {
		private int currentIndex;
		private Node<T> currentNode;
		private int until;

		public LinkedListFromUntilIterator(Node<T> aux, int from, int until) {
			this.currentIndex = 1;
			this.currentNode = aux;
			this.until = until;
			for (int i = 1; i < from; i++) {
				if (currentNode == null) {
					break;
				}
				currentNode = currentNode.next;
				currentIndex++;
			}
		}

		public boolean hasNext() {
			return currentNode != null && currentIndex <= until;
		}

		public T next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			T elem = currentNode.elem;
			currentNode = currentNode.next;
			currentIndex++;
			return elem;
		}
	}

	// FIN ITERADORES

	@Override
	public int size() {
		int cont = 0;
		Node<T> aux = front;
		while (aux != null) {
			cont++;
			aux = aux.next;
		}
		return cont;
	}

	@Override
	public boolean isEmpty() {
		return (front == null);
	}

	@Override
	public void addFirst(T elem) {
		if (elem == null) {
			throw new NullPointerException();
		} else {
			Node<T> node = new Node<T>(elem);
			node.next = front;
			front = node;
		}
	}

	@Override
	public void addLast(T elem) {
		Node<T> node = new Node<T>(elem);

		if (elem == null) {
			throw new NullPointerException();
		} else if (isEmpty()) {
			node.next = front;
			front = node;
		} else {
			Node<T> aux = front;
			while (aux.next != null) {
				aux = aux.next;
			}
			aux.next = node;
		}
	}

	@Override
	public void addPenult(T elem) {
		Node<T> node = new Node<T>(elem);

		if (elem == null) {
			throw new NullPointerException();
		} else if (isEmpty()) {
			node.next = front;
			front = node;
		} else if (front.next == null) {
			node.next = front;
			front = node;
		} else {
			Node<T> aux = front;
			while (aux.next.next != null) {
				aux = aux.next;
			}
			node.next = aux.next;
			aux.next = node;
		}
	}

	@Override
	public void addPos(T elem, int position) {
		if (elem == null) {
	        throw new NullPointerException();
	    }
	
	    if (position <= 0) {
	        throw new IllegalArgumentException();
	    }
	
	    Node<T> node = new Node<>(elem);
	
	    if (position == 1) {
	        node.next = front;
	        front = node;
	        return;
	    }
	    
	    if (position > size()) {
	    	addLast(elem);
	    	return;
	    }
	
	    Node<T> aux = front;
	    for (int i = 1; i < position - 1; i++) {
	        if (aux == null) {
	            throw new IllegalArgumentException();
	        }
	        aux = aux.next;
	    }
	    if (aux == null) {
	        throw new IllegalArgumentException();
	    }
	
	    node.next = aux.next;
	    aux.next = node;
	}



	@Override
	public T removeFirst() throws EmptyCollectionException {
		T result = null;

		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		}

		result = front.elem;
		front = front.next;
		return result;
	}

	@Override
	public T removelast() throws EmptyCollectionException {
		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		}

		Node<T> aux = front;
		if (front.next == null) {
			front = null;
			return aux.elem;
		}

		while (aux.next.next != null) {
			aux = aux.next;
		}

		T result = aux.next.elem;
		aux.next = null;
		return result;
	}

	@Override
	public T removePenult() throws EmptyCollectionException {
		T result;
		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		} else if (front.next == null) {
			throw new NoSuchElementException();
		} else if (front.next.next == null) {
			result = front.elem;
			front = front.next;
		} else {
			Node<T> antepenult = front;
			while (antepenult.next.next.next != null) {
				antepenult = antepenult.next;
			}
			result = antepenult.next.elem;
			antepenult.next = antepenult.next.next;
		}
		return result;
	}

	@Override
	public T getElemPos(int position) {
	    if (position <= 0 || position > size()) {
	        throw new IllegalArgumentException();
	    }
	
	    Node<T> aux = front;
	    for (int i = 1; i < position; i++) {
	        aux = aux.next;
	    }
	
	    return aux.elem;
	}

	@Override
	public int getPosLast(T elem) {
		int lastPosition = 0;
		int i = 0;
		Node<T> aux = front;
		while (aux != null) {
			if (aux.elem.equals(elem)) {
				lastPosition = i + 1;
			}
			i++;
			aux = aux.next;
		}
		return lastPosition;
	}

	@Override
	public int removeAll(T elem) throws EmptyCollectionException {
		int position = 0;
		Node<T> previous, current;

		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		if(elem == null) {
			throw new NullPointerException();
		}
		
		previous = null;
		current = front;

		while (current != null) {
			if (current.elem.equals(elem)) {
				if (previous == null) {
					front = current.next;
				} else {
					previous.next = current.next;
				}
				position++;
			} else {
				previous = current;
			}
			current = current.next;
		}

		if (position == 0) {
			throw new NoSuchElementException();
		}

		return position;

	}

	@Override
	public INotOrderedList<T> reverse() {
		LinkedNotOrderedList<T> reversedList = new LinkedNotOrderedList<T>();
		Node<T> aux = front;
		while (aux != null) {
			reversedList.addFirst(aux.elem);
			aux = aux.next;
		}
		return reversedList;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("(");

		Node<T> current = front;

		while (current != null) {
			sb.append(current.elem);
			sb.append(" ");
			current = current.next;
		}

		sb.append(")");
		return sb.toString();
	}

	@Override
	public int removeElem(T elem) throws EmptyCollectionException {
		if(elem == null) throw new NullPointerException();
		if(isEmpty()) {
			throw new EmptyCollectionException("");
		}
		
		int contador = 0;
		boolean found = false;
		Node<T> aux = front;
		 
		if( aux.next==null ) {
			if(elem.equals(aux.elem)) {
				this.front = this.front.next;
				found = true;
			}
		} else {
			if(elem.equals(front.elem)) {
				contador++;
				found=true;
				front=front.next;
			} else {
				contador++;
				while(aux.next != null && !found) {
					if(elem.equals(aux.next.elem)) {
						aux.next = aux.next.next;
						found = true;
					} else {
						aux = aux.next;
					}
					contador++;
				}
			}
		}
		if (!found) throw new NoSuchElementException();
		return contador;
	}


	@Override
	public T removeElemPos(int position) throws EmptyCollectionException {
		if (isEmpty()) {
			throw new EmptyCollectionException("");
		}
		if (position > size() || position < 1) {
			throw new IllegalArgumentException();
		} else {
			Node<T> removed = null;
			if (position == 1) {
				removed = front;
				front = front.next;
			} else {
				Node<T> aux = front;
				int currentPosition = 1;
				while (removed == null) {
					if (currentPosition == position - 1) {
						removed = aux.next;
						aux.next = aux.next.next;
					}
					aux = aux.next;
					currentPosition++;
				}
			}
			return removed.elem;
		}
	}

	@Override
	public int removePosLast(T elem) throws EmptyCollectionException {
		if (isEmpty()) {
			throw new EmptyCollectionException("");
		}
		if(elem == null) {
			throw new NullPointerException();
		}
		if(getPosLast(elem) == 0) {
			throw new NoSuchElementException();
		}
		int lastIndex = getPosLast(elem);
		removeElemPos(lastIndex);
		return lastIndex;
	}

    @Override
   public String FromUntilNotIncluded(int from, int until) {
		StringBuilder sb = new StringBuilder();
		Node<T> aux = front;
		
		if (from <= 0 || until <= 0 || until < from) {
			throw new IllegalArgumentException();
		}
		
		if (from > size()) {
			return "()";
		}
		
		if (until > size()) {
			sb.append("(");
			int contador = 0;
			while(contador < from) {
				aux = aux.next;
				contador++;
			}
			for (int i = from;aux != null &&  i < size(); i++) {
				sb.append(aux.elem.toString());
				sb.append(" ");
				aux = aux.next;
			}
			sb.append(")");
			return sb.toString();
		}
		for (int i = 1; i < from; i++) {
			if (aux == null) {
				return "";
			}
			aux = aux.next;
		}

		sb.append("(");
		aux = aux.next;
		until = until - 1;
		for (int i = from;aux != null &&  i < until; i++) {
			sb.append(aux.elem.toString());
			sb.append(" ");
			aux = aux.next;
		}
		sb.append(")");
		return sb.toString();
	}


	@Override
	public Iterator<T> iterator() {
		return new LinkedListIterator<T>(front);
	}

	@Override
	public Iterator<T> evenPosIterator() {
		return new LinkedListPosIterator<T>(front);
	}

	@Override
	public Iterator<T> fromUntilIterator(int from, int until) {
		if (from <= 0 || until <= 0 || until < from) {
			throw new IllegalArgumentException();
		}

		return new LinkedListFromUntilIterator<T>(front, from, until);
	}

}