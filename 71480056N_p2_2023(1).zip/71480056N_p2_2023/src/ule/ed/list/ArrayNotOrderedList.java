package ule.ed.list;

import java.util.Iterator;
import java.util.NoSuchElementException;

import java.util.Iterator;
import java.util.NoSuchElementException;


import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayNotOrderedList<T> implements INotOrderedList<T> {
	static final int DEFAULT_CAPACITY=10;

    private T[] data;
	private int count;
	
	// NO SE PUEDEN AÑADIR MÁS ATRIBUTOS A LA LISTA IMPLEMENTADA CON ARRAYS

	

	private class ArrayNotOrderedListIterator<T> implements Iterator<T> {
		private int current;
		
		@Override
		public boolean hasNext() {
			return (current < count);
		}

		@SuppressWarnings("unchecked")
		@Override
		public T next() {
			if(!hasNext()) {
				throw new NoSuchElementException();
			}
			T element = (T) data[current];
			current ++;
			return element;
		}
	}

	
	private class ArrayNotOrderedPosListIterator<T> implements Iterator<T> {
		private int current = 1;

		@Override
		public boolean hasNext() {
			return (current < count);
		}

		@SuppressWarnings("unchecked")
		@Override
		public T next() {
			if(!hasNext()) {
				throw new NoSuchElementException();
			}
			T element = (T) data[current];
			current += 2;
			return element;
		}
	}
	
	private class ArrayNotOrderedListIteratorFromTo<T> implements Iterator<T> {
		private int current;
		private int end;
		
		public ArrayNotOrderedListIteratorFromTo(int from, int until) {
		    current = from - 1;
		    this.end = Math.min(until - 1, count - 1);
		}
		
		@Override
		public boolean hasNext() {
			return (current <= end);
		}

		@Override
		public T next() {
			if(!hasNext()) {
				throw new NoSuchElementException();
			}
			T element = (T) data[current];
			current ++;
			return element;
		}
	}
	// FIN ITERADORES
	
	
	@SuppressWarnings("unchecked")
	public  ArrayNotOrderedList() {
		 count = 0;
		 data = (T[])(new Object[DEFAULT_CAPACITY]);
	}

	@SuppressWarnings("unchecked")
	public  ArrayNotOrderedList(int capacity) {
		count = 0;
		data = (T[])(new Object[capacity]);
	}
	
	@Override
	public int size() {
		return count;
	}

	@Override
	public boolean isEmpty() {
		return (count == 0);
	}

	@Override
	public void addFirst(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		if(count == data.length) {
			T[] larger = (T[]) new Object[data.length * 2];
			for(int i = 0; i < data.length; i++) {
				larger[i+1] = data[i];
			}
			data = larger;
		}
		else {
			for (int i = count - 1; i >= 0; i--) {
				data[i+1] = data[i];
			}
		}
		data[0] = elem;
		count++;
	}

	@Override
	public void addLast(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		if(count == data.length) {
			T[] larger = (T[]) new Object[data.length * 2];
			for(int i = 0; i < data.length; i++) {
				larger[i] = data[i];
			}
			data = larger;
		}
		if(isEmpty()) {
				data[0] = elem;
				count++;
		}
			
		else {	
			data[count] = elem;
			count++;
		}
	}

	@Override
	public void addPenult(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		
		if(count == data.length) {
			T[] larger = (T[]) new Object[data.length * 2];
			for(int i = 0; i < data.length; i++) {
				larger[i] = data[i];
			}
			data = larger;
		}
		
		if(isEmpty()) {
			data[0] = elem;
			count++;
		}
		
		else {
			data[count] = data[count - 1];
			data[count - 1] = elem;
			count++;
		}
	}

	@Override
	public void addPos(T elem, int position) {
		if (elem == null) {
	        throw new NullPointerException();
	    }

	    if (position <= 0) {
	        throw new IllegalArgumentException();
	    }
	    
	    if (position > size()) {
	    	addLast(elem);
	    	return;
	    }

	    if (count == data.length) {
	        T[] larger = (T[]) new Object[data.length * 2];
	        for (int i = 0; i < count; i++) {
	            larger[i] = data[i];
	        }
	        data = larger;
	    }
	    for (int i = count - 1; i >= position - 1; i--) {
	        data[i + 1] = data[i];
	    }
	    data[position - 1] = elem;
	    count++;
	}


	@Override
	public T removeFirst() throws EmptyCollectionException {
		if(isEmpty()) {
				throw new EmptyCollectionException("SET");
		}
		
		T result = data[0];
		data[0] = null;
		for(int i= 0; i< count; i++){ 
		     data[i] = data[i+1];
		}
		data[count - 1] = null;
		count--;
		return result;
	}

	@Override
	public T removelast() throws EmptyCollectionException {
		if(isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		T aux = data[count - 1];
		data[count - 1] = null;
		count--;
		return aux;
	}

	@Override
	public T removePenult() throws EmptyCollectionException {
		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		if (count < 2) {
			throw new NoSuchElementException("Error: no hay penultimo elemento");
		}
		T penult = data[count - 2];
		data[count - 2] = data[count - 1];
		data[count - 1] = null;
		count--;
		return penult;
	}

	@Override
	public int removeElem(T elem) throws EmptyCollectionException {
		if(elem == null) throw new NullPointerException();
		if(isEmpty()) {
			throw new EmptyCollectionException("");
		}
		
		int i = 0;
		int position  = 0;
		boolean found = false;
		
		while (i < count && !found) {
			if(data[i].equals(elem)) {
				position = i;
				found = true;
			}
			i++;
		}
		
		if (!found) {
			throw new NoSuchElementException();
		}
		
		for (int j = position; j <= count - 1; j++) {
			data[j] = data [j+1];
		}
		
		data[count - 1]= null;
		count--;
		
		return position + 1;
	}
	
	@Override
	public T getElemPos(int position) {
		T elem = null;
		
		if (position <= 0 || position > size()) {
			throw new IllegalArgumentException();
		}
		
		elem = data[position - 1];
		return elem;
	}

	@Override
	public int getPosLast(T elem) { 
		int position = -1;
		int i = count - 1;
		
		if (elem == null) {
			throw new NullPointerException();
		}
		
		while (i >= 0) {
			if(data[i].equals(elem)) {
				position = i;
				break;
			}
			i--;
		}
		
		if (position == -1) {
			throw new NoSuchElementException();
		}
		
		return position + 1;
	}

		@Override
	public int removeAll(T elem) throws EmptyCollectionException {
		if (elem == null) {
			throw new NullPointerException();
		}
		
		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		
		boolean found = false;
		int i = -1;
		int position = 0;
		
		while (i < size()) {
			i++;
			if(data[i] != null && data[i].equals(elem)) {
				found = true;
				position++;
			}
		}
		
		for(int j = 0; j < position; j++) {
			removeElem(elem);
		}
		
		if(!found) {
			throw new NoSuchElementException();
		}
		return position;
	}
	
	@Override
	public INotOrderedList<T> reverse() {
	    if (isEmpty()) {
	        return new ArrayNotOrderedList<T>(DEFAULT_CAPACITY);
	    }

	    ArrayNotOrderedList<T> reversedList = new ArrayNotOrderedList<T>(count);
	    for (int i = count - 1; i >= 0; i--) {
	        reversedList.addLast(data[i]);
	    }
	    return reversedList;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("(");
	   
		for (int i = 0; i < size(); i++) {
	    	sb.append(data[i] + " ");
	   
		}
	    
		sb.append(")");
		return sb.toString();
	}
   
	@Override
	public T removeElemPos(int position) throws EmptyCollectionException {
		if (isEmpty()) {
			throw new EmptyCollectionException("Error: collection is empty");
		}
		
		if(position < 1 || position > count) {
			throw new IllegalArgumentException();
		}
		
		T result= data[position - 1];
		
		for (int i = position - 1; i < count - 1; i++) {
			data[i] = data [i+1];
		}
		
		data[count - 1]= null;
		count--;
		
		return result;
	}

	@Override
	public int removePosLast(T elem) throws EmptyCollectionException  {
		int position = -1;
		
		if (elem == null) {
			throw new NullPointerException();
		}
		
		if(isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		
		for (int i = count - 1; i >= 0; i--) {
	        if (data[i].equals(elem)) {
	            position = i;
	            break;
	        }
	    }
		
		if (position == -1) {
			throw new NoSuchElementException();
		}
		
		for (int j = position; j < count - 1; j++) {
			data[j] = data [j+1];
		}
		
		data[count - 1]= null;
		count--;
		
		return position + 1;
	}

	@Override
	public String FromUntilNotIncluded(int from, int until) {
	   		StringBuilder sb = new StringBuilder();
		if (from <= 0 || until <= 0 || until < from) {
			throw new IllegalArgumentException();
		}
		if (from > size()) {
			return "()";
		}
		if (until > size()) {
			sb.append("(");
			for(int i = from; i < size(); i++) {
				sb.append(data[i] + " ");
			}
			sb.append(")");
			return sb.toString();
		}
		until = until - 1;
		sb.append("(");
		for(int i = from; i < until; i++) {
			sb.append(data[i] + " ");
		}
		sb.append(")");
		return sb.toString();
	}
	
	@Override
	public Iterator<T> iterator() {
		return new ArrayNotOrderedListIterator<T>();
	}

	
	@Override
	public Iterator<T> fromUntilIterator(int from, int until) {
		if (from <= 0 || until <= 0 || until < from) {
			throw new IllegalArgumentException();
		}
		return new ArrayNotOrderedListIteratorFromTo<T>(from, until);
	}

	@Override
	public Iterator<T> evenPosIterator() {
		return new ArrayNotOrderedPosListIterator<T>();
	}
}
